﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FinalProjectSoftwareMaintenance
{
    public partial class Form2 : Form
    {
       public int total_price;
       public string items;
        private string username;
        private string password;
        public string GetUsername { set { username = value; } }
        public string GetPassword { set { password = value; } }

        
        public Form2()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (username == null)
            {
                MessageBox.Show("Please log in or create a user to book our services");
            }
            else
            {
                items = null;
                total_price = total_price * 0;


                if (checkBox1.Checked == true)
                {
                    total_price = total_price + 200 * (comboBox1.SelectedIndex + 1);
                    items = items + "\n" + checkBox1.Text;
                }
                if (checkBox2.Checked == true)
                {
                    total_price = total_price + 180 * (comboBox2.SelectedIndex + 1);
                    items = items + "\n" + checkBox2.Text;
                }
                if (checkBox5.Checked == true)
                {
                    total_price = total_price + 100 * (comboBox3.SelectedIndex + 1);
                    items = items + "\n" + checkBox5.Text;
                }
                if (checkBox4.Checked == true)
                {
                    total_price = total_price + 250 * (comboBox4.SelectedIndex + 1);
                    items = items + "\n" + checkBox4.Text;
                }
                if (checkBox3.Checked == true)
                {
                    total_price = total_price + 200 * (comboBox5.SelectedIndex + 1);
                    items = items + "\n" + checkBox3.Text;
                }
                if (checkBox6.Checked == true)
                {
                    total_price = total_price + 150 * (comboBox6.SelectedIndex + 1);
                    items = items + "\n" + checkBox6.Text;
                }
                if (checkBox8.Checked == true)
                {
                    total_price = total_price + 1000;
                    items = items + "\n" + checkBox8.Text;
                }
                if (checkBox7.Checked == true)
                {
                    total_price = total_price + 800;
                    items = items + "\n" + checkBox7.Text;
                }
                if (checkBox10.Checked == true)
                {
                    total_price = total_price + 400;
                    items = items + "\n" + checkBox10.Text;
                }
                if (checkBox9.Checked == true)
                {
                    total_price = total_price + 300;
                    items = items + "\n" + checkBox9.Text;
                }
                if (checkBox12.Checked == true)
                {
                    total_price = total_price + 500;
                    items = items + "\n" + checkBox12.Text;
                }
                if (checkBox11.Checked == true)
                {
                    total_price = total_price + 400;
                    items = items + "\n" + checkBox11.Text;
                }

                this.Hide();
                Form3 s = new Form3();
                s.Gettotal_price = total_price;
                s.GetUsername = username;
                s.Getitems = items;
                s.ShowDialog();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form6 S = new Form6();
            this.Hide();
            S.ShowDialog();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            if(username == null)
            {
                label2.Text = label2.Text + " guest";
            }else
            label2.Text = label2.Text +" "+ username;
            
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if(checkBox1.Checked == true)
            {
                total_price = total_price + 200 *(comboBox1.SelectedIndex+1);
                items = items +"\n" +checkBox1.Text;
             }
            if (checkBox2.Checked == true)
            {
                total_price = total_price + 180 * (comboBox2.SelectedIndex + 1);
                items = items + "\n" + checkBox2.Text;
            }
            if (checkBox5.Checked == true)
            {
                total_price = total_price + 100 * (comboBox3.SelectedIndex + 1);
                items = items + "\n" + checkBox5.Text;
            }
            if (checkBox4.Checked == true)
            {
                total_price = total_price + 250 * (comboBox4.SelectedIndex + 1);
                items = items + "\n" + checkBox4.Text;
            }
            if (checkBox3.Checked == true)
            {
                total_price = total_price + 200 * (comboBox5.SelectedIndex + 1);
                items = items + "\n" + checkBox3.Text;
            }
            if (checkBox6.Checked == true)
            {
                total_price = total_price + 150 * (comboBox6.SelectedIndex + 1);
                items = items + "\n" + checkBox6.Text;
            }
            if (checkBox8.Checked == true)
            {
                total_price = total_price + 1000;
                items = items + "\n" + checkBox8.Text;
            }
            if (checkBox7.Checked == true)
            {
                total_price = total_price + 800;
                items = items + "\n" + checkBox7.Text;
            }
            if (checkBox10.Checked == true)
            {
                total_price = total_price + 400;
                items = items + "\n" + checkBox10.Text;
            }
            if (checkBox9.Checked == true)
            {
                total_price = total_price + 300;
                items = items + "\n" + checkBox9.Text;
            }
            if (checkBox12.Checked == true)
            {
                total_price = total_price + 500;
                items = items + "\n" + checkBox12.Text;
            }
            if (checkBox11.Checked == true)
            {
                total_price = total_price + 400;
                items = items + "\n" + checkBox11.Text;
            }





            label3.Text = label3.Text + total_price;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            items = null;
            total_price = total_price*0;
            checkBox1.Checked = false;
            checkBox2.Checked = false;
            checkBox3.Checked = false;
            checkBox4.Checked = false;
            checkBox5.Checked = false;
            checkBox6.Checked = false;
            checkBox7.Checked = false;
            checkBox8.Checked = false;
            checkBox9.Checked = false;
            checkBox10.Checked = false;
            checkBox11.Checked = false;
            checkBox12.Checked = false;
            label3.Text = "Total Price: $";
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
