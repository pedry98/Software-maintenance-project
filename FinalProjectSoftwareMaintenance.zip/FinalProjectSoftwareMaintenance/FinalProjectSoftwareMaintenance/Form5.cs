﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FinalProjectSoftwareMaintenance
{
    public partial class Form5 : Form
    {
        string connectionString = "Data Source=80360PP;Initial Catalog=finaldatabase;Integrated Security=True";
        public Form5()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form5_Load(object sender, EventArgs e)
        {
            string connectionString = "Data Source=80360PP;Initial Catalog=finaldatabase;Integrated Security=True";
            SqlConnection con = new SqlConnection(connectionString);

            con.Open();
            DataTable dt = new DataTable();
            SqlDataAdapter adapt = new SqlDataAdapter("SELECT username,ServiceDate,Total_Payment from users", con);
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();



            


        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=80360PP;Initial Catalog=finaldatabase;Integrated Security=True";
            SqlConnection con = new SqlConnection(connectionString);

            con.Open();
            DataTable dt = new DataTable();
            SqlDataAdapter adapt = new SqlDataAdapter("SELECT username,ServiceDate,Total_Payment from users where username = '"+textBox1.Text+"'", con);
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {
           
            SqlConnection con = new SqlConnection(connectionString);

            con.Open();
            DataTable dt = new DataTable();
            SqlDataAdapter adapt = new SqlDataAdapter("SELECT username,ServiceDate,Total_Payment from users", con);
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection s = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();
                SqlDataReader reader;
                cmd.CommandText = "Update users Set ServiceDate = NULL,Total_Payment = NULL WHERE username = '" + textBox1.Text + "' ";

                cmd.CommandType = CommandType.Text;
                cmd.Connection = s;
                s.Open();
                reader = cmd.ExecuteReader();
                MessageBox.Show("Service Canceled Succesfully");
                s.Close();
            }
            catch (Exception r)
            {
                MessageBox.Show("Could not cancel the service, try later.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection s = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();
                SqlDataReader reader;
                cmd.CommandText = "Update users Set ServiceDate = '" + dateTimePicker1.Value + "' WHERE username = '" + textBox1.Text + "' ";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = s;
                s.Open();
                reader = cmd.ExecuteReader();
                MessageBox.Show("The order has been changed for " + dateTimePicker1.Value + "'");
                s.Close();




            }
            catch (Exception r)
            {
                MessageBox.Show("Could not select that date");
            }
        }
    

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form4 S = new Form4();
            this.Hide();
            S.ShowDialog();
        }
    }
}
