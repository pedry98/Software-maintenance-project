﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FinalProjectSoftwareMaintenance
{
    public partial class Form6 : Form
    {
        int HasData;
        string connectionString = "Data Source=80360PP;Initial Catalog=finaldatabase;Integrated Security=True";
        public Form6()
        {
            InitializeComponent();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
           

        }

        private void button4_Click(object sender, EventArgs e)
        {
            
            string query = "SELECT * FROM users where Username = '" + textBox1.Text + "' and Password = '"+textBox2.Text+"'";
            SqlConnection connect = new SqlConnection(connectionString);
            SqlDataAdapter adp = new SqlDataAdapter(query, connect);
            DataTable dt = new DataTable();
            connect.Open();
            HasData = adp.Fill(dt);
            connect.Close();
            if (HasData > 0)
            {
                textBox2.Text = dt.Rows[0][1].ToString();
                textBox3.Text = dt.Rows[0][2].ToString();
                textBox4.Text = dt.Rows[0][3].ToString();
                textBox5.Text = dt.Rows[0][4].ToString();
            }
            else
            {
                MessageBox.Show(textBox1.Text + " Username and Password must be correct!");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "")
            {
                MessageBox.Show("Please fill all the required information before creating the user");
            }
            else
            {
                try
                {

                    SqlConnection s = new SqlConnection(connectionString);
                    SqlCommand cmd = new SqlCommand();
                    SqlDataReader reader;
                    cmd.CommandText = "insert into users (Username,Password,Email, Gender,PhoneNumber) values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "', '" + textBox5.Text + "', '" + textBox4.Text + "')";
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = s;
                    s.Open();
                    reader = cmd.ExecuteReader();
                    MessageBox.Show("User created Succesfully");
                    s.Close();
                }
                catch (Exception r)
                {
                    MessageBox.Show("Could not create user.Try different username.");
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection s = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();
                SqlDataReader reader;
                cmd.CommandText = "Update users Set  Password = '" + textBox2.Text + "',Email = '" + textBox3.Text + "', PhoneNumber = '" + textBox5.Text + "', Gender = '" + textBox4.Text + "' WHERE username = '" + textBox1.Text + "'";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = s;
                s.Open();
                reader = cmd.ExecuteReader();
                MessageBox.Show("Information Updated Succesfully");
                s.Close();
            }
            catch (Exception r)
            {
                MessageBox.Show("Could not update database.Wrong username or password.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 s = new Form1();
            s.ShowDialog();
        }
    }
}
