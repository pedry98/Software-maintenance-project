﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FinalProjectSoftwareMaintenance
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "admin" && textBox2.Text == "12345")
            {
                this.Hide();
                Form4 z = new Form4();
                z.ShowDialog();
            }
            else
            if (textBox1.Text == "" && textBox2.Text == "")
            {

                Form2 S = new Form2();
                this.Hide();
                S.ShowDialog();
            } else
            {
                try
                {
                    String connectionString = "Data Source=80360PP;Initial Catalog=finaldatabase;Integrated Security=True";
                    SqlConnection sc = new SqlConnection(connectionString);
                    sc.Open();
                    SqlCommand cmd = new SqlCommand("Select* from users where username = '"+textBox1.Text+"' and Password = '"+textBox2.Text+"'", sc);
                  
                   if(cmd.ExecuteReader().Read())
                    {
                        Form2 S = new Form2();
                        S.GetUsername = textBox1.Text;
                        S.GetPassword = textBox2.Text;
                        
                        this.Hide();
                       
                    
                        S.ShowDialog();
                        }else
                    {
                    MessageBox.Show("Username or password Incorrect!");
                    }
         sc.Close();
                }
                catch(Exception ex)
                {

                }
            }
         }

        private void button3_Click(object sender, EventArgs e)
        {
            Form6 t = new Form6();
            this.Hide();
            t.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
           linkLabel1.LinkVisited = true;
            try
            {
                VisitLink();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to open link that was clicked.Check internet connection");
            }
        }

        private void VisitLink()
        {
            // Change the color of the link text by setting LinkVisited   
            // to true.  
            linkLabel1.LinkVisited = true;
            //Call the Process.Start method to open the default browser   
            //with a URL:  
            System.Diagnostics.Process.Start("https://www.facebook.com/DGPaintinginc/");
        }
    }
    }
    

