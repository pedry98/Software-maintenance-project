﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FinalProjectSoftwareMaintenance
{
    public partial class Form3 : Form
    {
        string cn = "Data Source=80360PP;Initial Catalog=finaldatabase;Integrated Security=True";
        string username;
        public string GetUsername { set { username = value; } }
       
        int total_price;
        string items;
        public int Gettotal_price { set { total_price = value; } }
        public string Getitems { set { items = value; } }
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {



            label3.Text = username;
            richTextBox1.Text = "Total Price: $" + total_price + "\nServices: \n" + items;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                
                SqlConnection s = new SqlConnection(cn);
                SqlCommand cmd = new SqlCommand();
                SqlDataReader reader;
                cmd.CommandText = "Update users Set ServiceDate = '" + dateTimePicker1.Value + "',Total_payment = '"+total_price+"' WHERE username = '" + username+ "' ";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = s;
                s.Open();
                reader = cmd.ExecuteReader();
                MessageBox.Show("Your order has been placed for " + dateTimePicker1.Value + " for a total price of " + total_price + "\nThank you for booking our services!");
                s.Close();


                
                
            }
            catch(Exception r)
            {
                MessageBox.Show("Could not select that date");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 z = new Form1();
            this.Hide();
            z.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 S = new Form2();
            S.Show();
        }
    }
}
