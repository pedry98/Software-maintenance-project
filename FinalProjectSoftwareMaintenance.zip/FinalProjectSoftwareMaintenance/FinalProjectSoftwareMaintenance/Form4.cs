﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FinalProjectSoftwareMaintenance
{
    public partial class Form4 : Form
    {
        int HasData;
        string connectionString = "Data Source=80360PP;Initial Catalog=finaldatabase;Integrated Security=True";
        public Form4()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=80360PP;Initial Catalog=finaldatabase;Integrated Security=True";

            string sql = "Select * from users";
            SqlConnection connection = new SqlConnection(connectionString);
            SqlDataAdapter dataadapter = new SqlDataAdapter(sql, connection);
            DataSet ds = new DataSet();
            connection.Open();
            dataadapter.Fill(ds, "users");
            connection.Close();
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "users";
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'finaldatabaseDataSet1.users' table. You can move, or remove it, as needed.
            this.usersTableAdapter.Fill(this.finaldatabaseDataSet1.users);

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form5 s = new Form5();
            this.Hide();
            s.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            string query = "SELECT * FROM users where Username = '" + textBox1.Text + "'";
            SqlConnection connect = new SqlConnection(connectionString);
            SqlDataAdapter adp = new SqlDataAdapter(query, connect);
            DataTable dt = new DataTable();
            connect.Open();
            HasData = adp.Fill(dt);
            connect.Close();
            if (HasData > 0)
            {
                textBox2.Text = dt.Rows[0][1].ToString();
                textBox3.Text = dt.Rows[0][2].ToString();
                textBox4.Text = dt.Rows[0][3].ToString();
                textBox5.Text = dt.Rows[0][4].ToString();
            }
            else
            {
                MessageBox.Show(textBox1.Text + " - not found in database!");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection s = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();
                SqlDataReader reader;
                cmd.CommandText = "Update users Set Password = '" + textBox2.Text + "', Email = '" + textBox3.Text + "', PhoneNumber = '" + textBox4.Text + "', Gender = '" + textBox5.Text + "' WHERE username = '" + textBox1.Text + "' ";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = s;
                s.Open();
                reader = cmd.ExecuteReader();
                MessageBox.Show("Information Updated Succesfully");
                s.Close();
            }
            catch (Exception r)
            {
                MessageBox.Show("Could not update database");
            }




        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection s = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand();
                SqlDataReader reader;
                cmd.CommandText = "delete from users where username = '" + textBox1.Text + "' and password = '" + textBox2.Text + "' ";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = s;
                s.Open();
                reader = cmd.ExecuteReader();
                MessageBox.Show("Information Deleted Succesfully");
                s.Close();
            }
            catch (Exception r)
            {
                MessageBox.Show("Could not delete from the database");
            }






            
}

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 S = new Form1();
            S.ShowDialog();
        }
    }
}
